/* =========================================================
   TyranoMath 공통 기능 (index.html · gamezone.html 함께 사용)
   ※ 게임 목록·설정은 data.js 에서 고쳐요. 이 파일은 고치지 않아도 돼요.
   ========================================================= */
(function(){
'use strict';

// data.js 의 CONFIG · GAMES · CHECKS 를 읽어요 (없어도 오류 없이 동작)
const CFG = Object.assign({ bugReportUrl:'', latestCount:4, newDays:14, statsUrl:'' }, typeof CONFIG !== 'undefined' ? CONFIG : {});
window.TM_STATS_URL = CFG.statsUrl || '';   // 게임 창(랭킹)이 이 주소를 함께 써요
const GAME_LIST  = typeof GAMES  !== 'undefined' && Array.isArray(GAMES)  ? GAMES  : [];
const UNIT_LIST  = typeof UNITS  !== 'undefined' && Array.isArray(UNITS)  ? UNITS  : [];
const BEST_LIST  = typeof BEST   !== 'undefined' && Array.isArray(BEST)   ? BEST   : [];
const PUZZLE_LIST = typeof PUZZLES !== 'undefined' && Array.isArray(PUZZLES) ? PUZZLES : [];
const TOOL_LIST = typeof TOOLS !== 'undefined' && Array.isArray(TOOLS) ? TOOLS : [];
const LISTS = { games: GAME_LIST, puzzles: PUZZLE_LIST, tools: TOOL_LIST };
// 퍼즐존 분류
const PUZZLE_TYPES = [
  { name:'수 퍼즐',   icon:'🔢' },
  { name:'전략 퍼즐', icon:'♟️' },
  { name:'논리 퍼즐', icon:'💡' },
  { name:'도형 퍼즐', icon:'🔷' }
];
// 2022 개정 교육과정 4개 영역
const AREAS = [
  { name:'수와 연산',     icon:'🔢', color:'#FFE7CC', desc:'수 · 사칙계산 · 분수와 소수' },
  { name:'변화와 관계',   icon:'🔁', color:'#E4F5D6', desc:'규칙 · 식 · 비와 비례' },
  { name:'도형과 측정',   icon:'🔺', color:'#DDF0FF', desc:'도형 · 길이 · 시간 · 넓이' },
  { name:'자료와 가능성', icon:'📊', color:'#FFE3EA', desc:'분류 · 표와 그래프 · 가능성' }
];

/* ---------- 도우미 ---------- */
const store = {
  get(k){ try{ return localStorage.getItem(k); }catch(e){ return null; } },
  set(k,v){ try{ localStorage.setItem(k,v); }catch(e){} }
};
const $  = (s, el=document) => el.querySelector(s);
const $$ = (s, el=document) => [...el.querySelectorAll(s)];
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function toast(msg){
  const t = $('#toast'); if (!t) return;
  t.textContent = msg; t.classList.add('show');
  clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.remove('show'), 2200);
}
function isNew(item){
  if (!item.date) return false;
  const d = new Date(item.date + 'T00:00:00');
  if (isNaN(d)) return false;
  const days = (Date.now() - d.getTime()) / 86400000;
  return days >= -1 && days <= CFG.newDays;
}
function gradeRange(g){
  const nums = String(g || '').match(/\d+/g);
  if (!nums) return [1, 6];
  const a = Number(nums[0]), b = Number(nums[nums.length - 1]);
  return [Math.min(a, b), Math.max(a, b)];
}
const byLatest = (a, b) => (b.item.date || '').localeCompare(a.item.date || '') || b.i - a.i;
// data.js 에서 pin: 1, 2 … 를 붙인 항목은 '최신순'에서 늘 맨 앞 (번호 순서대로), 나머지는 그 뒤에 최신순
const byPinLatest = (a, b) => ((a.item.pin || 999) - (b.item.pin || 999)) || byLatest(a, b);

/* =========================================================
   1. 번역 기능 (Google 번역)
   ========================================================= */
const LANGS = [
  ['ko','한국어'],['en','English'],['ja','日本語'],['zh-CN','中文(简体)'],['zh-TW','中文(繁體)'],
  ['vi','Tiếng Việt'],['th','ไทย'],['id','Bahasa Indonesia'],['ms','Bahasa Melayu'],['tl','Filipino'],
  ['mn','Монгол'],['uz','Oʻzbek'],['kk','Қазақ'],['ru','Русский'],['uk','Українська'],
  ['hi','हिन्दी'],['bn','বাংলা'],['ne','नेपाली'],['ur','اردو'],['ar','العربية'],
  ['fa','فارسی'],['tr','Türkçe'],['km','ខ្មែរ'],['lo','ລາວ'],['my','မြန်မာ'],
  ['es','Español'],['fr','Français'],['de','Deutsch'],['pt','Português'],['it','Italiano'],
  ['nl','Nederlands'],['pl','Polski'],['sv','Svenska'],['el','Ελληνικά'],['he','עברית'],
  ['sw','Kiswahili'],['am','አማርኛ'],['si','සිංහල'],['ta','தமிழ்']
];
function currentLang(){
  const m = document.cookie.match(/(?:^|;\s*)googtrans=\/[^/]*\/([^;]+)/);
  return m ? decodeURIComponent(m[1]) : 'ko';
}
function setCookie(val, clear){
  const host = location.hostname;
  const exp = clear ? ';expires=Thu, 01 Jan 1970 00:00:00 GMT' : '';
  document.cookie = 'googtrans=' + val + ';path=/' + exp;
  if (host && host.includes('.')) document.cookie = 'googtrans=' + val + ';path=/;domain=' + host + exp;
}
function setLang(code){
  if (code === 'ko'){ setCookie('', true); location.reload(); return; }
  setCookie('/ko/' + code);
  const combo = document.querySelector('.goog-te-combo');
  if (combo){ combo.value = code; combo.dispatchEvent(new Event('change')); renderLangUI(); closeLang(); }
  else location.reload();
}
function renderLangUI(filter=''){
  const cur = currentLang();
  const found = LANGS.find(l => l[0] === cur);
  $('#langCurrent').textContent = found ? found[1] : cur;
  const list = $('#langList'); list.innerHTML = '';
  const f = filter.trim().toLowerCase();
  LANGS.filter(([c,n]) => !f || n.toLowerCase().includes(f) || c.toLowerCase().includes(f)).forEach(([c,n]) => {
    const b = document.createElement('button');
    b.type = 'button'; b.textContent = n; b.lang = c;
    b.setAttribute('aria-current', c === cur ? 'true' : 'false');
    b.addEventListener('click', () => setLang(c));
    list.appendChild(b);
  });
}
function openLang(){ $('#langPanel').classList.add('open'); $('#langBtn').setAttribute('aria-expanded','true'); $('#langSearch').focus(); }
function closeLang(){ $('#langPanel').classList.remove('open'); $('#langBtn').setAttribute('aria-expanded','false'); }
if ($('#langBtn')){
  $('#langBtn').addEventListener('click', e => { e.stopPropagation(); $('#langPanel').classList.contains('open') ? closeLang() : openLang(); });
  $('#langPanel').addEventListener('click', e => e.stopPropagation());
  document.addEventListener('click', closeLang);
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeLang(); });
  $('#langSearch').addEventListener('input', e => renderLangUI(e.target.value));
  renderLangUI();
  window.googleTranslateElementInit = function(){
    new google.translate.TranslateElement({ pageLanguage:'ko', autoDisplay:false }, 'google_translate_element');
  };
  const s = document.createElement('script');
  s.src = 'https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';
  s.async = true; document.body.appendChild(s);
}

/* =========================================================
   2. 기기별 화면 설정 (모든 페이지가 같은 설정을 기억해요)
   ========================================================= */
const MODE_NAMES = { pc:'컴퓨터', phone:'스마트폰', pad:'패드', board:'전자칠판' };
const SCALES = [0.85, 1, 1.15, 1.3, 1.5];
let modeChoice = store.get('tm-mode') || 'auto';
let scaleIdx = Number(store.get('tm-scale') ?? 1);
if (!(scaleIdx >= 0 && scaleIdx < SCALES.length)) scaleIdx = 1;

function detectDevice(){
  const w = window.innerWidth;
  const touch = window.matchMedia('(pointer: coarse)').matches || navigator.maxTouchPoints > 0;
  if (w < 640) return 'phone';
  if (touch && w >= 1600) return 'board';
  if (touch) return 'pad';
  return 'pc';
}
function applyMode(){
  const actual = modeChoice === 'auto' ? detectDevice() : modeChoice;
  document.documentElement.dataset.device = actual;
  $$('.tab').forEach(t => t.setAttribute('aria-selected', t.dataset.mode === modeChoice ? 'true' : 'false'));
  if ($('#autoHint')) $('#autoHint').textContent = modeChoice === 'auto' ? '(감지됨: ' + MODE_NAMES[actual] + ')' : '';
  document.documentElement.style.setProperty('--scale', SCALES[scaleIdx]);
}
$$('.tab').forEach(t => t.addEventListener('click', () => { modeChoice = t.dataset.mode; store.set('tm-mode', modeChoice); applyMode(); }));
$('#fontUp')?.addEventListener('click', () => { scaleIdx = Math.min(SCALES.length-1, scaleIdx+1); store.set('tm-scale', scaleIdx); applyMode(); });
$('#fontDown')?.addEventListener('click', () => { scaleIdx = Math.max(0, scaleIdx-1); store.set('tm-scale', scaleIdx); applyMode(); });
$('#fullBtn')?.addEventListener('click', () => {
  const d = document;
  if (!d.fullscreenElement){ (d.documentElement.requestFullscreen || d.documentElement.webkitRequestFullscreen || (()=>{})).call(d.documentElement); }
  else { (d.exitFullscreen || d.webkitExitFullscreen).call(d); }
});
document.addEventListener('fullscreenchange', () => {
  if ($('#fullBtn')) $('#fullBtn').textContent = document.fullscreenElement ? '⛶ 전체 화면 끄기' : '⛶ 전체 화면';
});
let rT; window.addEventListener('resize', () => { clearTimeout(rT); rT = setTimeout(() => { if (modeChoice === 'auto') applyMode(); }, 150); });
applyMode();

/* =========================================================
   3. 버그 제보 탭
   ========================================================= */
const bugTab = $('#bugTab');
if (bugTab){
  // 구글 시트(statsUrl)가 있으면 사이트 안 게시판으로, 설문지 주소(bugReportUrl)만 있으면 설문지로 가요
  if (CFG.bugReportUrl && !CFG.statsUrl){ bugTab.href = CFG.bugReportUrl; bugTab.target = '_blank'; bugTab.rel = 'noopener'; }
  else { bugTab.href = 'bugboard.html'; bugTab.removeAttribute('target'); }
}

/* =========================================================
   4. 카드 그리기
   ========================================================= */
function cardHTML(key, i, opts={}){
  const g = LISTS[key][i];
  const verb = key === 'tools' ? '▶ 열기' : '▶ 시작하기';
  const newBadge = g.file && isNew(g) ? '<span class="badge-new">NEW</span>' : '';
  return `
    <button type="button" class="game${g.file ? '' : ' soon'}" data-list="${key}" data-i="${i}" ${g.file ? '' : 'aria-disabled="true"'}>
      ${newBadge}
      <div class="thumb" style="background:${esc(g.color || '#E4F5D6')}">
        ${g.image ? `<img src="${esc(g.image)}" alt="" loading="lazy">` : `<span aria-hidden="true">${esc(g.icon || '🎲')}</span>`}
      </div>
      <div class="body">
        <h3>${esc(g.title)}</h3>
        <p>${esc(g.desc)}</p>
        <div class="chips">
          ${g.grade ? `<span class="chip">${esc(g.grade)}</span>` : ''}
          ${g.area && opts.showArea !== false ? `<span class="chip area">${esc(g.area)}</span>` : ''}
        </div>
        <span class="play">${g.file ? verb : '준비 중'}</span>
      </div>
    </button>`;
}
function renderInto(el, key, indexes){
  el.innerHTML = indexes.map(i => cardHTML(key, i)).join('');
}
document.addEventListener('click', e => {
  const b = e.target.closest('.game[data-list], .best-card[data-list]');
  if (b) openItem(b.dataset.list, Number(b.dataset.i));
});

/* =========================================================
   5. 게임 플레이어 (홈페이지 안에서 크게 열기)
   ========================================================= */
let lastFocus = null, returnHash = '';
// 이 기기에서 게임을 연 횟수 기록 (인기 게임 자동 순위에 사용)
function getPlays(){ try { return JSON.parse(store.get('tm-plays') || '{}') || {}; } catch(e){ return {}; } }
function countPlay(file){
  const p = getPlays(); p[file] = (p[file] || 0) + 1; store.set('tm-plays', JSON.stringify(p));
  // 구글 시트에도 +1 (게임 파일만, 실패해도 게임은 그대로 열려요)
  if (CFG.statsUrl && /^(games|puzzles|tools)\//.test(file)){
    try { fetch(CFG.statsUrl + '?action=hit&file=' + encodeURIComponent(file), { mode:'no-cors', keepalive:true }).catch(() => {}); } catch(e){}
  }
}
// 구글 시트에서 전체 플레이 수 가져오기 (4초 안에 응답이 없으면 포기)
async function fetchGlobalPlays(){
  if (!CFG.statsUrl) return null;
  const ctrl = new AbortController(); const t = setTimeout(() => ctrl.abort(), 4000);
  try {
    const res = await fetch(CFG.statsUrl + '?action=list', { signal: ctrl.signal });
    const data = await res.json();
    return data && data.ok && data.counts ? data.counts : null;
  } catch(e){ return null; } finally { clearTimeout(t); }
}
function openItem(key, i){ openEntry(LISTS[key] && LISTS[key][i]); }
// entry = { title, icon, file, newTab }
function openEntry(g){
  if (!g || !g.file){ toast('곧 만나요! 열심히 만들고 있어요 🛠️'); return; }
  countPlay(g.file);
  if (g.newTab){ window.open(g.file, '_blank', 'noopener'); return; }
  lastFocus = document.activeElement;
  returnHash = location.hash.startsWith('#game=') ? '' : location.hash;
  $('#playerTitle').innerHTML = `<span aria-hidden="true">${g.icon === '🦖' ? '<svg class="dino-ico" viewBox="2 4 212 190"><use href="#dino"/></svg>' : esc(g.icon || '🎮')}</span><span>${esc(g.title)}</span>`;
  $('#playerFrame').src = g.file;
  $('#player').classList.add('open');
  document.body.classList.add('no-scroll');
  $('#playerClose').focus();
  try { history.replaceState(null, '', '#game=' + encodeURIComponent(g.file)); } catch(e){}
  goBig();                                       // 고른 순간(누른 동작)에 바로 '크게' 화면으로 시작해요
}
// '크게' = 게임 창을 모니터 전체로 (지원하지 않는 기기에서는 화면 가득한 창 그대로)
function goBig(){
  const box = $('.player-box');
  if (!box || document.fullscreenElement || document.webkitFullscreenElement) return;
  try { const r = (box.requestFullscreen || box.webkitRequestFullscreen)?.call(box); if (r && r.catch) r.catch(() => {}); } catch(e){}
}
function toggleBig(){
  if (document.fullscreenElement || document.webkitFullscreenElement){ (document.exitFullscreen || document.webkitExitFullscreen)?.call(document); return; }
  const box = $('.player-box'), fn = box && (box.requestFullscreen || box.webkitRequestFullscreen);
  if (!fn){ toast('이 기기에서는 크게 보기를 지원하지 않아요'); return; }
  try { const r = fn.call(box); if (r && r.catch) r.catch(() => {}); } catch(e){}
}
/* 게임 안의 윗줄 버튼(소리·일시정지·설정·랭킹)을 게임 창 윗줄로 옮겨 한 줄로 합쳐요.
   진짜 버튼은 게임 안에 그대로 두고, 윗줄 버튼을 누르면 게임 안의 버튼이 눌려요. */
/* Esc 를 스스로 쓰는 도구(<meta name="tm-keep-esc">)가 열려 있는지 */
function keepEsc(){
  try { const p = $('#player'), d = $('#playerFrame').contentDocument;
    return !!(p && p.classList.contains('open') && d && d.querySelector('meta[name="tm-keep-esc"]')); } catch(e){ return false; }
}
/* 크롬·엣지: 전체 화면에서 짧게 누른 Esc 가 전체 화면을 끄지 않고 도구로 가게 해요 (Esc 길게 누르기·'크게' 버튼으로 끝내요) */
function escLock(){
  try { const k = navigator.keyboard; if (!k || !k.lock) return;
    if ((document.fullscreenElement || document.webkitFullscreenElement) && keepEsc()) k.lock(['Escape']).catch(() => {}); else k.unlock(); } catch(e){}
}
let mergeObs = null;
function mergeBar(){
  const slot = $('#playerTools'); if (!slot) return;
  if (mergeObs){ mergeObs.disconnect(); mergeObs = null; }
  slot.innerHTML = ''; $('#player').classList.remove('merged'); unmirror();
  let doc; try { doc = $('#playerFrame').contentDocument; } catch(e){ return; }
  const tools = doc && doc.querySelector('.topbar .tools'); if (!tools) return;
  // 게임 이름(브랜드)과 버튼 줄만 숨기고, 다른 것(도구 막대 등)이 같은 줄에 있으면 그 줄은 남겨요
  const bar = tools.closest('.topbar');
  const tbar = bar.querySelector(':scope > .toolbar');      // 도구 막대(펜·지우개 등)도 창 윗줄로 옮겨요
  const others = [...bar.children].filter(el => el !== tools && el !== tbar && !el.classList.contains('brand'));
  const st = doc.createElement('style');
  st.textContent = others.length ? '.topbar > .brand, .topbar > .tools, .topbar > .toolbar{display:none!important}' : '.topbar{display:none!important}';
  doc.head.appendChild(st);
  if (tbar) mirrorToolbar(tbar);
  $('#player').classList.add('merged');
  const draw = () => {
    slot.innerHTML = '';
    [...tools.children].forEach(src => {
      if (src.id === 'btnZone' || src.id === 'btnFull' || src.hidden) return;
      const b = document.createElement('button'); b.type = 'button';
      b.className = 'tool gtool' + (src.classList.contains('set') ? ' g-set' : '') + (src.classList.contains('tmr-btn') ? ' g-rank' : '');
      b.innerHTML = src.innerHTML; b.disabled = !!src.disabled;
      if (src.hasAttribute('aria-pressed')) b.setAttribute('aria-pressed', src.getAttribute('aria-pressed'));
      b.setAttribute('aria-label', src.getAttribute('aria-label') || src.textContent.trim());
      b.addEventListener('click', () => src.click());
      slot.appendChild(b);
    });
  };
  draw();
  mergeObs = new MutationObserver(draw);
  mergeObs.observe(tools, { subtree: true, childList: true, attributes: true, characterData: true });
}
// 도구 막대를 똑같이 그려 두고, 누르면 게임 안의 진짜 버튼이 눌려요
let tbarObs = null;
function mirrorToolbar(src){
  let slot = $('#playerTbar');
  if (!slot){ slot = document.createElement('div'); slot.id = 'playerTbar'; slot.className = 'player-tbar'; $('#playerTitle').after(slot); }
  const path = el => { const p = []; while (el && el !== slot){ p.unshift([...el.parentNode.children].indexOf(el)); el = el.parentNode; } return p; };
  const draw = () => {
    slot.innerHTML = src.innerHTML.replace(/\sid="/g, ' data-src-id="');
    slot.hidden = false; $('#player').classList.add('has-tbar');
  };
  slot.onclick = e => {
    const b = e.target.closest('button'); if (!b || !slot.contains(b)) return;
    let node = src; for (const i of path(b)) node = node && node.children[i];
    if (node) node.click();
  };
  draw();
  tbarObs = new MutationObserver(draw);
  tbarObs.observe(src, { subtree: true, childList: true, attributes: true, characterData: true });
}
function unmirror(){
  if (tbarObs){ tbarObs.disconnect(); tbarObs = null; }
  const slot = $('#playerTbar'); if (slot){ slot.innerHTML = ''; slot.hidden = true; }
  $('#player') && $('#player').classList.remove('has-tbar');
}
function closeItem(){
  if (!$('#player') || !$('#player').classList.contains('open')) return;
  try { navigator.keyboard?.unlock?.(); } catch(e){}
  if (document.fullscreenElement) document.exitFullscreen?.();
  $('#player').classList.remove('open');
  $('#playerFrame').src = 'about:blank';
  if (mergeObs){ mergeObs.disconnect(); mergeObs = null; }
  if ($('#playerTools')) $('#playerTools').innerHTML = '';
  unmirror();
  $('#player').classList.remove('merged');
  document.body.classList.remove('no-scroll');
  try { history.replaceState(null, '', location.pathname + location.search + returnHash); } catch(e){}
  lastFocus?.focus();
}
if ($('#player') && !$('#playerTools')){
  const slot = document.createElement('div'); slot.id = 'playerTools'; slot.className = 'player-gtools';
  $('#playerReload').before(slot);
}
if ($('#player')){
  $('#playerClose').addEventListener('click', closeItem);
  $('#player').addEventListener('click', e => { if (e.target.id === 'player') closeItem(); });
  document.addEventListener('keydown', e => { if (e.key !== 'Escape') return;
    if (keepEsc()){ // 2D 기하도구처럼 Esc 를 스스로 쓰는 도구: 창을 닫지 않고 도구에 Esc 를 넘겨요
      try { const f = $('#playerFrame'); f.contentWindow.focus(); f.contentDocument.dispatchEvent(new KeyboardEvent('keydown', { key:'Escape', code:'Escape', bubbles:true, cancelable:true })); } catch(err){}
      return; }
    closeItem(); });
  document.addEventListener('fullscreenchange', escLock);
  // 게임 화면 안에서 Esc 를 눌러도 닫히게 (같은 사이트의 게임일 때)
  $('#playerFrame').addEventListener('load', () => {
    try { $('#playerFrame').contentWindow.addEventListener('keydown', e => { if (e.key === 'Escape' && !e.defaultPrevented) closeItem(); }); } catch(e){}
    mergeBar(); escLock();
  });
  $('#playerReload').addEventListener('click', () => { const f = $('#playerFrame'); const src = f.src; f.src = 'about:blank'; setTimeout(() => f.src = src, 50); });
  $('#playerFull').addEventListener('click', toggleBig);
}

/* =========================================================
   6. 메인 화면: 실력 진단소 + 최신 게임
   ========================================================= */
const KINDS = {
  learn: { field:'learn', board:'#learnBoard', icon:'🦖', go:'▶ 배우기',  label:'개념 탐험대' },
  check: { field:'check', board:'#checkBoard', icon:'🎯', go:'▶ 진단하기', label:'실력 진단소' }
};
function unitEntry(kind, i){
  const u = UNIT_LIST[i], k = KINDS[kind];
  const head = `${u.grade}학년${u.sem ? ` ${u.sem}학기` : ''}`;
  return { title: `${head} · ${u.no ? u.no + '. ' : ''}${u.title}`, icon: k.icon, file: u[k.field], newTab: u.newTab };
}
// 학년을 고르면 1학기 · 2학기 두 칸에 단원이 번호 순서대로 나와요
const SEMS = [
  { sem:1, icon:'🌸', color:'#E4F5D6', sub:'3월 ~ 7월' },
  { sem:2, icon:'🍁', color:'#FFE7CC', sub:'8월 ~ 2월' }
];
function renderBoard(kind, grade){
  const k = KINDS[kind], board = $(k.board); if (!board) return;
  const areaOf = name => AREAS.find(a => a.name === name);
  board.innerHTML = SEMS.map(S => {
    const rows = UNIT_LIST.map((u, i) => ({ u, i }))
      .filter(r => Number(r.u.grade) === grade && Number(r.u.sem || 1) === S.sem)
      .sort((x, y) => (x.u.no || 0) - (y.u.no || 0));
    const ready = rows.filter(r => r.u[k.field]).length;
    const list = rows.length
      ? `<ul class="unit-list">${rows.map(r => {
          const has = !!r.u[k.field], a = areaOf(r.u.area);
          const tag = a ? `<small class="area-tag" style="background:${a.color}" title="${esc(a.name)}"><span aria-hidden="true">${a.icon}</span> ${esc(a.name)}</small>` : '';
          return `<li><button type="button" class="unit${has ? '' : ' soon'}" data-kind="${kind}" data-u="${r.i}" ${has ? '' : 'aria-disabled="true"'}>
            <span class="no">${r.u.no || ''}</span><span class="t">${esc(r.u.title)}${tag}</span><span class="go">${has ? k.go : '준비 중'}</span></button></li>`;
        }).join('')}</ul>`
      : '<p class="unit-empty">이 학기에는 아직 단원이 없어요.</p>';
    return `<div class="area-box sem-box">
      <div class="area-head" style="background:${S.color}"><span class="ic" aria-hidden="true">${S.icon}</span>
        <div><h3>${grade}학년 ${S.sem}학기</h3><small>${rows.length}개 단원${ready ? ` · ${ready}개 열림` : ''}</small></div></div>
      ${list}</div>`;
  }).join('');
}
$$('.grade-tabs').forEach(tabs => {
  const kind = tabs.dataset.for, key = 'tm-grade-' + kind;
  let grade = Number(store.get(key)) || 1;
  tabs.innerHTML = [1,2,3,4,5,6].map(g => `<button type="button" role="tab" data-g="${g}" aria-selected="${g === grade}"><span class="n">${g}</span>학년</button>`).join('');
  tabs.addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    grade = Number(b.dataset.g); store.set(key, grade);
    $$('button', tabs).forEach(x => x.setAttribute('aria-selected', x === b ? 'true' : 'false'));
    renderBoard(kind, grade);
  });
  renderBoard(kind, grade);
});
document.addEventListener('click', e => {
  const b = e.target.closest('.unit[data-kind]');
  if (b) openEntry(unitEntry(b.dataset.kind, Number(b.dataset.u)));
});
// data-latest="games" 또는 "puzzles" 인 칸에 최신 항목을 보여 줘요
$$('[data-latest]').forEach(el => {
  const key = el.dataset.latest, list = LISTS[key] || [];
  let latest = list.map((item, i) => ({ item, i })).filter(x => x.item.file).sort(byPinLatest).slice(0, CFG.latestCount).map(x => x.i);
  // 아직 열린 것이 적으면 '준비 중'인 것도 함께 보여 줘요 (수학 도구존)
  if (key === 'tools' && latest.length < CFG.latestCount)
    latest = latest.concat(list.map((item, i) => ({ item, i })).filter(x => !x.item.file).slice(0, CFG.latestCount - latest.length).map(x => x.i));
  renderInto(el, key, latest);
});

/* =========================================================
   7-1. 🔥 인기 게임 BEST 10
   ========================================================= */
if ($('#bestTrack')){
  const track = $('#bestTrack');
  const ready = GAME_LIST.map((item, i) => ({ item, i })).filter(r => r.item.file);
  let ranked = [];
  function renderBest(plays, global){
    if (BEST_LIST.length){
      // data.js 의 BEST 순서대로 (목록에 없는 경로는 건너뛰어요)
      ranked = BEST_LIST.map(f => ready.find(r => r.item.file === f)).filter(Boolean);
    } else {
      ranked = [...ready].sort((a, b) => (plays[b.item.file] || 0) - (plays[a.item.file] || 0) || byLatest(a, b));
    }
    ranked = ranked.slice(0, 10);
    track.innerHTML = ranked.length ? ranked.map((r, n) => {
      const g = r.item, cnt = plays[g.file] || 0;
      return `<button type="button" class="best-card" data-list="games" data-i="${r.i}" title="${esc(g.title)}">
        <div class="thumb" style="background:${esc(g.color || '#E4F5D6')}">
          <span class="rank${n < 3 ? ' r' + (n + 1) : ''}">${n + 1}</span>
          ${g.image ? `<img src="${esc(g.image)}" alt="" loading="lazy">` : `<span aria-hidden="true">${esc(g.icon || '🎲')}</span>`}
          ${global && cnt ? `<span class="plays">▶ ${cnt.toLocaleString()}회</span>` : ''}
        </div>
        <div class="name">${esc(g.title)}</div>
      </button>`;
    }).join('') : '<p class="best-empty">아직 게임이 없어요.</p>';
    if (typeof updateNav === 'function') updateNav();
  }
  renderBest(getPlays(), false);                 // 먼저 이 기기 기준으로 바로 보여 주고
  fetchGlobalPlays().then(c => { if (c) { renderBest(c, true); track.scrollLeft = 0; } });   // 시트 응답이 오면 전체 기준으로 바꿔요

  const per = () => Number(getComputedStyle(track).getPropertyValue('--per')) || 5;
  const pages = () => Math.max(1, Math.ceil(ranked.length / per()));
  const page = () => Math.min(pages(), Math.round(track.scrollLeft / Math.max(1, track.clientWidth)) + 1);
  var updateNav = function(){
    const p = page(), total = pages();
    $('#bestPage').textContent = `${p} / ${total}`;
    $('#bestPrev').disabled = p <= 1;
    $('#bestNext').disabled = p >= total;
  };
  $('#bestPrev').addEventListener('click', () => track.scrollBy({ left: -track.clientWidth, behavior: 'smooth' }));
  $('#bestNext').addEventListener('click', () => track.scrollBy({ left: track.clientWidth, behavior: 'smooth' }));
  let sT; track.addEventListener('scroll', () => { clearTimeout(sT); sT = setTimeout(updateNav, 80); });
  window.addEventListener('resize', updateNav);
  $$('.tab').forEach(t => t.addEventListener('click', () => setTimeout(updateNav, 50)));
  updateNav();
}

/* =========================================================
   7. 티라노 게임존 페이지: 영역·학년·검색·정렬
   ========================================================= */
if ($('#zoneGrid')){
  // 게임존(games) / 퍼즐존(puzzles) 공통 — <main data-list="..."> 로 구분해요
  const ZKEY = ($('main[data-list]') && $('main[data-list]').dataset.list) || 'games';
  const ZLIST = LISTS[ZKEY] || [];
  const NOUN = ZKEY === 'puzzles' ? '퍼즐' : ZKEY === 'tools' ? '도구' : '게임';
  const state = { area: '전체', grade: '0', q: '', sort: 'new' };
  const ready = ZLIST.filter(g => g.file);
  $('#statTotal').textContent = ready.length;
  $('#statNew').textContent = ready.filter(isNew).length;

  // 영역 버튼
  const chips = ZKEY === 'puzzles' ? [{ name:'전체', icon:'🧩' }, ...PUZZLE_TYPES] : [{ name:'전체', icon: ZKEY === 'tools' ? '🧰' : '🎮' }, ...AREAS];
  $('#areaChips').innerHTML = chips.map(a => {
    const n = a.name === '전체' ? ZLIST.length : ZLIST.filter(g => g.area === a.name).length;
    return `<button type="button" data-area="${esc(a.name)}" aria-pressed="${a.name === '전체'}"><span aria-hidden="true">${a.icon}</span>${esc(a.name)}<small>${n}</small></button>`;
  }).join('');
  $('#areaChips').addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    state.area = b.dataset.area;
    $$('#areaChips button').forEach(x => x.setAttribute('aria-pressed', x === b ? 'true' : 'false'));
    renderZone();
  });
  $('#gradeSel').addEventListener('change', e => { state.grade = e.target.value; renderZone(); });
  $('#sortSel').addEventListener('change', e => { state.sort = e.target.value; renderZone(); });
  $('#searchBox').addEventListener('input', e => { state.q = e.target.value.trim().toLowerCase(); renderZone(); });

  // 주소에 ?area=도형과 측정 이 있으면 그 영역부터 보여 줘요
  const qa = new URLSearchParams(location.search).get('area');
  if (qa && chips.some(c => c.name === qa)){
    state.area = qa;
    $$('#areaChips button').forEach(x => x.setAttribute('aria-pressed', x.dataset.area === qa ? 'true' : 'false'));
  }

  function renderZone(){
    let rows = ZLIST.map((item, i) => ({ item, i }));
    if (state.area !== '전체') rows = rows.filter(r => r.item.area === state.area);
    if (state.grade !== '0'){
      const g = Number(state.grade);
      rows = rows.filter(r => { const [a, b] = gradeRange(r.item.grade); return g >= a && g <= b; });
    }
    if (state.q) rows = rows.filter(r => [r.item.title, r.item.desc, r.item.area, r.item.grade].join(' ').toLowerCase().includes(state.q));
    if (state.sort === 'name') rows.sort((a, b) => a.item.title.localeCompare(b.item.title, 'ko'));
    else if (state.sort === 'grade') rows.sort((a, b) => gradeRange(a.item.grade)[0] - gradeRange(b.item.grade)[0] || byLatest(a, b));
    else rows.sort(byPinLatest);
    // 준비 중인 게임은 항상 뒤로
    rows.sort((a, b) => (!a.item.file) - (!b.item.file));

    $('#zoneCount').textContent = `${rows.length}개의 ${NOUN}`;
    $('#zoneEmpty').hidden = rows.length > 0;
    renderInto($('#zoneGrid'), ZKEY, rows.map(r => r.i));
  }
  renderZone();
}

/* =========================================================
   8. 주소에 #game=파일 이 있으면 바로 열기 (수업용 바로가기 링크)
   ========================================================= */
(function openFromHash(){
  const m = location.hash.match(/^#game=(.+)$/);
  if (!m || !$('#player')) return;
  const file = decodeURIComponent(m[1]);
  for (const key of ['games', 'puzzles', 'tools']){
    const gi = LISTS[key].findIndex(g => g.file === file);
    if (gi >= 0) return openItem(key, gi);
  }
  for (const kind of ['learn', 'check']){
    const ui = UNIT_LIST.findIndex(u => u[KINDS[kind].field] === file);
    if (ui >= 0) return openEntry(unitEntry(kind, ui));
  }
})();


/* =========================================================
   👀 방문자 수 (아래쪽 footer) — 구글 시트(statsUrl)에서 세요
   한 기기는 하루에 한 번만 셉니다.
   ========================================================= */
(function visitors(){
  const ft = document.querySelector('footer .wrap');
  if (!ft || !CFG.statsUrl) return;
  const box = document.createElement('div'); box.className = 'visitors'; box.setAttribute('aria-live', 'polite');
  box.innerHTML = '<span aria-hidden="true">👀</span> 방문자 세는 중…';
  ft.prepend(box);
  const d = new Date(Date.now() + 9 * 3600000).toISOString().slice(0, 10);   // 한국 날짜
  let dev = store.get('tm-rank-dev');
  if (!dev){ dev = 'd' + Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4); store.set('tm-rank-dev', dev); }
  const isNew = store.get('tm-visit-day') !== d;
  const ctrl = new AbortController(); setTimeout(() => ctrl.abort(), 20000);
  fetch(CFG.statsUrl + '?action=visit&new=' + (isNew ? 1 : 0) + '&d=' + encodeURIComponent(dev), { signal: ctrl.signal })
    .then(r => r.json()).then(v => {
      if (!v || !v.ok) throw 0;
      if (isNew) store.set('tm-visit-day', d);
      const f = n => Number(n || 0).toLocaleString();
      box.innerHTML = `<span aria-hidden="true">👀</span> 전체 방문자 <b>${f(v.total)}</b>명`;
    }).catch(() => box.remove());
})();

window.TyranoMath = { toast, openItem, openEntry, closeItem };
})();
